

function todaysDate()
{
	

	var dt = new Date();
document.getElementById('Date').innerHTML=dt;
}
function changeColour() {
	document.getElementById("changeColour").style.border = "0.3em  dotted yellow";

	
  }
